/**
 * 
 */
package no.hvl.dat152.obl3.util;


public class ServerConfig {
	
	public static final int PORT = 9092;
	public static final String DEFAULT_DICT_URL = "http://localhost:"+PORT+"/DAT152WebSearchOblig3/v003/";
	

}
