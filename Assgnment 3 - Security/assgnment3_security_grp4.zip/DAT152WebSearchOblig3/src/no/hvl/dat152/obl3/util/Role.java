/**
 * 
 */
package no.hvl.dat152.obl3.util;

public enum Role {
	ADMIN,
	USER
}
