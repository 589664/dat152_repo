/**
 * 
 */
package no.hvl.dat152.obl3.idp.oauth.utility;

public enum Scope {
	
	openid,
	email,
	phone,
	profile,
	address

}
