package no.hvl.dat152.obl3.database;

public class DatabaseSettings {
  static final String source = "java:comp/env/jdbc/DAT152"; 
}
