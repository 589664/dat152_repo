/**
 * 
 */
package no.hvl.dat152.obl3.blog.util;


public enum Role {
	ADMIN,
	USER
}
